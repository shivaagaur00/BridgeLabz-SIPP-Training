
// Exercise 5: Create and Use a Repeatable Annotation
import java.lang.annotation.*;
import java.lang.reflect.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@Repeatable(BugReports.class)
@interface BugReport {
    String description();
}

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface BugReports {
    BugReport[] value();
}

class BugTracker {
    @BugReport(description = "Null pointer issue")
    @BugReport(description = "Array index out of bound")
    public void process() {
        System.out.println("Processing...");
    }

    public static void main(String[] args) throws Exception {
        Method m = BugTracker.class.getMethod("process");
        BugReport[] reports = m.getAnnotationsByType(BugReport.class);
        for (BugReport report : reports) {
            System.out.println("Bug: " + report.description());
        }
    }
}
