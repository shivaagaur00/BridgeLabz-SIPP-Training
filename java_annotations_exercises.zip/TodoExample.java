
// Beginner 2: Create a @Todo Annotation for Pending Tasks
import java.lang.annotation.*;
import java.lang.reflect.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface Todo {
    String task();
    String assignedTo();
    String priority() default "MEDIUM";
}

class Project {
    @Todo(task = "Implement login", assignedTo = "Shiva")
    public void login() {}

    @Todo(task = "Implement logout", assignedTo = "Amit", priority = "HIGH")
    public void logout() {}

    public static void main(String[] args) throws Exception {
        for (Method m : Project.class.getDeclaredMethods()) {
            if (m.isAnnotationPresent(Todo.class)) {
                Todo t = m.getAnnotation(Todo.class);
                System.out.println("Task: " + t.task() + " | Assigned: " + t.assignedTo() + " | Priority: " + t.priority());
            }
        }
    }
}
