
// Exercise 2: Use @Deprecated to Mark an Old Method
class LegacyAPI {
    @Deprecated
    void oldFeature() {
        System.out.println("Old feature - don't use!");
    }

    void newFeature() {
        System.out.println("New feature is here!");
    }

    public static void main(String[] args) {
        LegacyAPI api = new LegacyAPI();
        api.oldFeature(); // Shows warning
        api.newFeature();
    }
}
