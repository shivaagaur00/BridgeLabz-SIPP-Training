
// Exercise 3: Suppress Unchecked Warnings
import java.util.*;

class SuppressWarningExample {
    @SuppressWarnings("unchecked")
    public static void main(String[] args) {
        List list = new ArrayList(); // raw type
        list.add("Hello");
        list.add(123);
        for (Object obj : list) {
            System.out.println(obj);
        }
    }
}
