
// Intermediate 4: Create a @MaxLength Annotation for Field Validation
import java.lang.annotation.*;
import java.lang.reflect.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface MaxLength {
    int value();
}

class User {
    @MaxLength(10)
    String username;

    public User(String username) throws Exception {
        this.username = username;
        for (var field : User.class.getDeclaredFields()) {
            if (field.isAnnotationPresent(MaxLength.class)) {
                MaxLength max = field.getAnnotation(MaxLength.class);
                String value = (String) field.get(this);
                if (value.length() > max.value()) {
                    throw new IllegalArgumentException("Field " + field.getName() + " exceeds max length " + max.value());
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        try {
            new User("ShortName");
            new User("ThisNameIsTooLong");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
