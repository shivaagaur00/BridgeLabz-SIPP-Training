
// Advanced 7: Implement a Custom Caching System with @CacheResult
import java.lang.annotation.*;
import java.lang.reflect.*;
import java.util.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface CacheResult {}

class Calculator {
    private static final Map<Integer, Integer> cache = new HashMap<>();

    @CacheResult
    public int expensiveComputation(int n) {
        if (cache.containsKey(n)) {
            System.out.println("Returning cached result for " + n);
            return cache.get(n);
        }
        int result = 0;
        for (int i = 0; i < n * 100000; i++) {
            result += i % 10;
        }
        cache.put(n, result);
        System.out.println("Computed result for " + n);
        return result;
    }

    public static void main(String[] args) throws Exception {
        Calculator c = new Calculator();
        System.out.println(c.expensiveComputation(5));
        System.out.println(c.expensiveComputation(5)); // Cached
    }
}
