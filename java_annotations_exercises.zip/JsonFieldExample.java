
// Advanced 6: Implement a Custom Serialization Annotation @JsonField
import java.lang.annotation.*;
import java.lang.reflect.*;
import java.util.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface JsonField {
    String name();
}

class UserJson {
    @JsonField(name = "user_name")
    String username;

    @JsonField(name = "email_address")
    String email;

    public UserJson(String username, String email) {
        this.username = username;
        this.email = email;
    }

    public String toJson() throws Exception {
        Map<String, String> jsonMap = new HashMap<>();
        for (var field : this.getClass().getDeclaredFields()) {
            if (field.isAnnotationPresent(JsonField.class)) {
                JsonField jf = field.getAnnotation(JsonField.class);
                jsonMap.put(jf.name(), (String) field.get(this));
            }
        }
        return jsonMap.toString();
    }

    public static void main(String[] args) throws Exception {
        UserJson u = new UserJson("Shiva", "shiva@example.com");
        System.out.println(u.toJson());
    }
}
