
// Basic 4: Dynamically Create Objects
import java.lang.reflect.*;

class Student {
    String name;
    public Student() {
        this.name = "Default Student";
    }
}

public class DynamicObjectCreation {
    public static void main(String[] args) throws Exception {
        Class<?> clazz = Class.forName("Student");
        Object obj = clazz.getDeclaredConstructor().newInstance();
        System.out.println("Created object: " + obj.getClass().getName());
    }
}
