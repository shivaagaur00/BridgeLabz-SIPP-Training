
// Intermediate 1: Dynamic Method Invocation
import java.lang.reflect.*;

class MathOperations {
    public int add(int a, int b) { return a + b; }
    public int subtract(int a, int b) { return a - b; }
    public int multiply(int a, int b) { return a * b; }
}

public class DynamicMethodInvocation {
    public static void main(String[] args) throws Exception {
        MathOperations m = new MathOperations();
        Method method = MathOperations.class.getMethod("multiply", int.class, int.class);
        Object result = method.invoke(m, 6, 7);
        System.out.println("Result: " + result);
    }
}
