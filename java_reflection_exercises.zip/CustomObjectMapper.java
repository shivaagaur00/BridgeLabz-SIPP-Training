
// Advanced 1: Custom Object Mapper
import java.lang.reflect.*;
import java.util.*;

class Employee {
    String name;
    int id;
}

public class CustomObjectMapper {
    public static <T> T toObject(Class<T> clazz, Map<String, Object> properties) throws Exception {
        T obj = clazz.getDeclaredConstructor().newInstance();
        for (var entry : properties.entrySet()) {
            Field field = clazz.getDeclaredField(entry.getKey());
            field.setAccessible(true);
            field.set(obj, entry.getValue());
        }
        return obj;
    }

    public static void main(String[] args) throws Exception {
        Map<String, Object> data = new HashMap<>();
        data.put("name", "Shiva");
        data.put("id", 101);
        Employee e = toObject(Employee.class, data);
        System.out.println("Employee: " + e.name + " | ID: " + e.id);
    }
}
