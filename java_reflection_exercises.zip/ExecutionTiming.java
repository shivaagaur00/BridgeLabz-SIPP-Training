
// Advanced 5: Method Execution Timing
import java.lang.reflect.*;

class Task {
    public void quickTask() {
        for (int i = 0; i < 1000; i++);
    }

    public void slowTask() {
        for (int i = 0; i < 1000000; i++);
    }
}

public class ExecutionTiming {
    public static void main(String[] args) throws Exception {
        Task t = new Task();
        for (Method m : Task.class.getDeclaredMethods()) {
            long start = System.nanoTime();
            m.invoke(t);
            long end = System.nanoTime();
            System.out.println(m.getName() + " executed in " + (end - start) + " ns");
        }
    }
}
