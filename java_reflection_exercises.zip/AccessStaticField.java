
// Intermediate 3: Access and Modify Static Fields
import java.lang.reflect.*;

class Configuration {
    private static String API_KEY = "OLD_KEY";
}

public class AccessStaticField {
    public static void main(String[] args) throws Exception {
        Field field = Configuration.class.getDeclaredField("API_KEY");
        field.setAccessible(true);
        System.out.println("Original Key: " + field.get(null));
        field.set(null, "NEW_KEY");
        System.out.println("Modified Key: " + field.get(null));
    }
}
