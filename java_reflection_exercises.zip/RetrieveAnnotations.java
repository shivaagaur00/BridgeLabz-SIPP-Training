
// Intermediate 2: Retrieve Annotations at Runtime
import java.lang.annotation.*;
import java.lang.reflect.*;

@Retention(RetentionPolicy.RUNTIME)
@interface Author {
    String name();
}

@Author(name="Shiva")
class Demo {}

public class RetrieveAnnotations {
    public static void main(String[] args) {
        Author author = Demo.class.getAnnotation(Author.class);
        if (author != null) {
            System.out.println("Author: " + author.name());
        }
    }
}
