
// Advanced 2: Generate a JSON Representation
import java.lang.reflect.*;

class User {
    String username = "Shiva";
    String email = "shiva@example.com";
}

public class JsonReflection {
    public static void main(String[] args) throws Exception {
        User u = new User();
        StringBuilder json = new StringBuilder("{");
        Field[] fields = User.class.getDeclaredFields();
        for (int i = 0; i < fields.length; i++) {
            fields[i].setAccessible(true);
            json.append("\"" + fields[i].getName() + "\": \"" + fields[i].get(u) + "\"");
            if (i < fields.length - 1) json.append(", ");
        }
        json.append("}");
        System.out.println(json.toString());
    }
}
